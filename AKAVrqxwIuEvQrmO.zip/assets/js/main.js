/* WOJSTAL – skrypty strony głównej
   Bez zależności zewnętrznych. Strona działa również bez JavaScriptu. */

(function () {
  'use strict';

  /* --- Menu mobilne ------------------------------------------------------ */
  var header = document.getElementById('site-header');
  var toggle = document.getElementById('navToggle');

  if (header && toggle) {
    toggle.addEventListener('click', function () {
      var open = header.classList.toggle('is-open');
      toggle.setAttribute('aria-expanded', open ? 'true' : 'false');
    });

    // Zamknij menu po wybraniu pozycji
    header.querySelectorAll('.nav a').forEach(function (link) {
      link.addEventListener('click', function () {
        header.classList.remove('is-open');
        toggle.setAttribute('aria-expanded', 'false');
      });
    });

    // Zamknij klawiszem Escape
    document.addEventListener('keydown', function (event) {
      if (event.key === 'Escape' && header.classList.contains('is-open')) {
        header.classList.remove('is-open');
        toggle.setAttribute('aria-expanded', 'false');
        toggle.focus();
      }
    });
  }

  /* --- Delikatne wejście sekcji ----------------------------------------- */
  var reveals = document.querySelectorAll('.reveal');
  var reduceMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;

  if (reduceMotion || !('IntersectionObserver' in window)) {
    reveals.forEach(function (el) { el.classList.add('is-visible'); });
  } else {
    var observer = new IntersectionObserver(function (entries) {
      entries.forEach(function (entry) {
        if (entry.isIntersecting) {
          entry.target.classList.add('is-visible');
          observer.unobserve(entry.target);
        }
      });
    }, { rootMargin: '0px 0px -8% 0px', threshold: 0.06 });

    reveals.forEach(function (el) { observer.observe(el); });
  }

  /* --- Formularz wyceny: złożenie wiadomości e-mail ---------------------- */
  var form = document.getElementById('quoteForm');
  var status = document.getElementById('formStatus');

  if (form) {
    form.addEventListener('submit', function (event) {
      event.preventDefault();

      if (!form.checkValidity()) {
        form.reportValidity();
        return;
      }

      var value = function (id) {
        var el = document.getElementById(id);
        return el && el.value ? el.value.trim() : '';
      };

      var subject = 'Zapytanie o wycenę: ' + value('f-product') + ' – ' + value('f-name');
      var body = [
        'Imię i nazwisko: ' + value('f-name'),
        'Telefon: ' + value('f-phone'),
        'E-mail: ' + value('f-email'),
        'Zakres zapytania: ' + value('f-product'),
        '',
        'Szczegóły:',
        value('f-message'),
        '',
        '--',
        'Wiadomość wysłana z formularza na stronie producentgarazy.pl'
      ].join('\r\n');

      window.location.href = 'mailto:biuro@producentgarazy.pl'
        + '?subject=' + encodeURIComponent(subject)
        + '&body=' + encodeURIComponent(body);

      if (status) {
        status.textContent = 'Otwieramy program pocztowy z gotową wiadomością. '
          + 'Jeśli się nie otworzył, zadzwoń: +48 18 332 00 18.';
        status.classList.add('is-visible');
      }
    });
  }

  /* --- Bieżący rok w stopce --------------------------------------------- */
  var year = document.getElementById('year');
  if (year) {
    year.textContent = String(new Date().getFullYear());
  }
}());
