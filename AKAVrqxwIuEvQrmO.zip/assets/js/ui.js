/* WOJSTAL – interakcje podstron: rozwijane menu, galeria z powiększaniem */

(function () {
  'use strict';

  /* --- Rozwijane pozycje menu (dotyk i klawiatura) ----------------------- */
  document.querySelectorAll('.nav__item').forEach(function (item) {
    var trigger = item.querySelector('a');
    var sub = item.querySelector('.nav__sub');
    if (!trigger || !sub) return;

    trigger.addEventListener('click', function (event) {
      var narrow = window.matchMedia('(max-width: 1080px)').matches;
      if (!narrow) return;
      event.preventDefault();
      var open = item.classList.toggle('is-open');
      trigger.setAttribute('aria-expanded', open ? 'true' : 'false');
    });
  });

  /* --- Galeria z powiększaniem ------------------------------------------- */
  var galleryFigures = document.querySelectorAll('.gallery-grid figure');
  if (galleryFigures.length) {
    var box = document.createElement('div');
    box.className = 'lightbox';
    box.setAttribute('role', 'dialog');
    box.setAttribute('aria-modal', 'true');
    box.setAttribute('aria-label', 'Powiększone zdjęcie realizacji');
    box.innerHTML = '<button class="lightbox__close" type="button" aria-label="Zamknij">&times;</button>'
      + '<button class="lightbox__nav lightbox__nav--prev" type="button" aria-label="Poprzednie">&#8249;</button>'
      + '<img alt="">'
      + '<button class="lightbox__nav lightbox__nav--next" type="button" aria-label="Następne">&#8250;</button>'
      + '<p class="lightbox__caption"></p>';
    document.body.appendChild(box);

    var image = box.querySelector('img');
    var caption = box.querySelector('.lightbox__caption');
    var items = Array.prototype.slice.call(galleryFigures);
    var current = 0;

    function show(index) {
      current = (index + items.length) % items.length;
      var fig = items[current];
      var img = fig.querySelector('img');
      image.src = img.currentSrc || img.src;
      image.alt = img.alt || '';
      caption.textContent = (fig.querySelector('figcaption') || {}).textContent || '';
      box.classList.add('is-open');
      document.body.style.overflow = 'hidden';
    }

    function hide() {
      box.classList.remove('is-open');
      document.body.style.overflow = '';
    }

    items.forEach(function (fig, i) {
      fig.setAttribute('tabindex', '0');
      fig.addEventListener('click', function () { show(i); });
      fig.addEventListener('keydown', function (event) {
        if (event.key === 'Enter' || event.key === ' ') { event.preventDefault(); show(i); }
      });
    });

    box.querySelector('.lightbox__close').addEventListener('click', hide);
    box.querySelector('.lightbox__nav--prev').addEventListener('click', function () { show(current - 1); });
    box.querySelector('.lightbox__nav--next').addEventListener('click', function () { show(current + 1); });
    box.addEventListener('click', function (event) { if (event.target === box) hide(); });
    document.addEventListener('keydown', function (event) {
      if (!box.classList.contains('is-open')) return;
      if (event.key === 'Escape') hide();
      if (event.key === 'ArrowLeft') show(current - 1);
      if (event.key === 'ArrowRight') show(current + 1);
    });
  }

  /* --- Filtr galerii realizacji ------------------------------------------ */
  var filterBar = document.querySelector('[data-gallery-filter]');
  if (filterBar) {
    filterBar.addEventListener('click', function (event) {
      var button = event.target.closest('button[data-filter]');
      if (!button) return;
      var value = button.getAttribute('data-filter');
      filterBar.querySelectorAll('button').forEach(function (b) {
        b.classList.toggle('is-active', b === button);
      });
      document.querySelectorAll('.gallery-grid figure').forEach(function (fig) {
        var group = fig.getAttribute('data-group') || '';
        fig.style.display = (value === 'all' || group === value) ? '' : 'none';
      });
    });
  }
}());