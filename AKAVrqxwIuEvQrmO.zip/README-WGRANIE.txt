WOJSTAL – nowa strona www (wersja statyczna, gotowa do wgrania)
================================================================

CO JEST W PACZCE
----------------
- 250 gotowych stron HTML: strona główna, 15 podstron (oferta, garaże blaszane,
  euro garaże, garaże drewnopodobne, lekkie hale stalowe, wiaty śmietnikowe,
  kojce dla psów, paleta kolorów, realizacje, o firmie, jak przygotować podłoże,
  strefa wiedzy, darmowa wycena, kontakt), 68 stron miast i 167 poradników.
- assets/  – styl CSS, skrypty, wszystkie zdjęcia (w tym galeria 102 realizacji).
- sitemap.xml, robots.txt, favicon.svg, apple-touch-icon.png – pliki dla Google.
- Każda podstrona ma własny adres w katalogu (np. /oferta/index.html).

JAK WGRAC
---------
1. Rozpakuj paczkę i wgraj CAŁĄ ZAWARTOŚĆ folderu do katalogu głównego
   domeny (np. public_html/ lub httpdocs/). Plik index.html musi znaleźć się
   bezpośrednio w katalogu głównym.
2. Strona jest w 100% statyczna – nie wymaga PHP, bazy danych ani instalacji.
   Działa na każdym hostingu (także zwykły hosting HTML).
3. Włącz przekierowanie na HTTPS i ustaw adresy bez "www" albo z "www"
   (jedna wersja, druga przekierowana) – adresy kanoniczne w kodzie wskazują
   na https://producentgarazy.pl/
4. W Google Search Console dodaj nową mapę strony:
   https://producentgarazy.pl/sitemap.xml

CO WARTO UZUPEŁNIĆ PO WGRANIU
-----------------------------
- Formularz wyceny (podstrony „Darmowa wycena” i „Kontakt”) działa obecnie tak,
  że po kliknięciu otwiera program pocztowy użytkownika z gotową treścią wiadomości.
  Jeśli chcesz, można go podłączyć do wysyłki przez serwer (PHP/Formspree itp.).
- Zdjęcia wewnątrz poradników i na stronach miast są na razie podlinkowane
  z obecnej strony (producentgarazy.pl). Po wgraniu można je przenieść do
  katalogu assets/img i podmienić adresy, aby strona była w pełni samodzielna.
- W pliku assets/img/og-image.jpg jest grafika do udostępniania w social media –
  można ją podmienić na własną (zalecane 1200 x 630 px).

DANE KONTAKTOWE W KODZIE
------------------------
Telefony: +48 18 332 00 18, +48 18 332 00 23, +48 604 98 51 56, +48 795 47 72 96
E-mail: biuro@producentgarazy.pl
Adres: P.P.H. „Wojstal” Czepiel Wojciech, 34-623 Szczyrzyc 115, BDO 000364899
